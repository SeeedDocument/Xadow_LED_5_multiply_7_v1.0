#include <string.h>
#include <TimerOne.h>
#include "LED.h"
#include "font.h"

const int negative_pins[] = {MATRIX_N0,MATRIX_N1,MATRIX_N2,MATRIX_N3,MATRIX_N4};
const int positive_pins[] = {MATRIX_P0,MATRIX_P1,MATRIX_P2,MATRIX_P3,
							MATRIX_P4,MATRIX_P5,MATRIX_P6 };
#define TIMER1_PERIOD 50//50ms for the timer1 interrupt
unsigned char display_buff[6];
volatile uint16_t interruptions;// the number of timer1 interruptions to be set
volatile uint16_t timer1_count;//count the actual number of timer1 interruptions
void timerIsr();
volatile boolean flag_timeout;
void LED5x7::init()
{
	initDriveIOs();
	setOrientation(RIGHT_TO_LEFT);
	Timer1.initialize((long)TIMER1_PERIOD*1000); //set a timer of length TIMER1_PERIOD  
}

void LED5x7::initDriveIOs()
{
	for(unsigned char i = 0; i < 5;i ++)
	{
		pinMode(negative_pins[i],OUTPUT);
	}
	for(unsigned char i = 0; i < 7;i ++)
	{
		pinMode(positive_pins[i],OUTPUT);
	}
	turnOffLEDMatrix();
}
/**********************************************************************/
/*Function: Print an ASCII character on the Xadow LED5X7.             */
/*Parameter:-uint8_t ascii,the ASCII code of a character;             */
/*          -uint16_t display_time,the duration of character display  */
/*			 and the unit is ms.									  */
/*Return:	void                      			                      */
void LED5x7::print(uint8_t ascii,uint16_t display_time)
{
	for(uint8_t i = 0;i < 5;i ++)
	{
		uint16_t temp=(ascii-32)*5+i;// get the 1/5 code address for each asc;
		display_buff[i]= pgm_read_byte(&Font5x7[temp]);//get the code 
	}
	printWithTime(display_time);
}
void LED5x7::printNumber(uint8_t number)
{
/*
   unsigned char nBIT=0x10;
  for(unsigned char i=0;i<5;i++)
  {
    if(number>99)
    {
      number =99;
    }
    unsigned char tempL=number%10;
    tempL=tempL*5+i;
    tempL = pgm_read_byte(&Seg[tempL]);

    unsigned char tempH=number/10;
    tempH=tempH*5+i;
    tempH = pgm_read_byte(&Seg[tempH]);
    tempH <<=4;
    turnOffLEDMatrix();
    if(i<1)
    {
      PORTD &=~ nBIT;
    }
    else
    {
      PORTC &=~ nBIT;
    }
    nBIT >>=1; 
    
      PORTB |= tempL+tempH&0x07;//
      delayMicroseconds(10);
      PORTD &=~ 0x60;
	  PORTB &=~ 0x1f;
      PORTD |= tempH&0x60;
      PORTB |= tempH&0x18;//
      delayMicroseconds(10);
      PORTD &=~ 0x60;
	  PORTB &=~ 0x1f;
  }*/
	if(number>99) number =99;
	uint8_t units,tens;
	units = number % 10;
	tens  = number / 10;
	uint8_t tempL,tempH;
	for(uint8_t i = 0;i < 5;i ++)
	{
		tempL =  units*5+i;
		tempL =  pgm_read_byte(&Seg[tempL]);
		tempH =  tens*5+i;
		tempH =  pgm_read_byte(&Seg[tempH]);
    	tempH <<=4;
		display_buff[i] = tempH | tempL;
	}
	printWithTime(200);
}
/**********************************************************************/
/*Function: Print a string on the Xadow LED5x7 and it will flow.      */
/*Parameter:-const String,all the bytes in the string is ASIIC code.  */
/*          -uint16_t moving_time,The time of the character moving one*/
/*			 step.													  */
/*Return:	void                      			                      */
void LED5x7::print(const String &s,uint16_t moving_time)
{
	unsigned char currenr_seg_num = 5;
	for (uint16_t i = 0; i < s.length()+1;)
	{
		if(currenr_seg_num == 5)//it's time to read 5 bytes of a new character
		{
			if(i < s.length())
			{
				for(unsigned char j = 0;j < 5;j ++)
				{
					unsigned int index = (s[i]-32)*5+j;// get the 1/5 code address for each asc;
					display_buff[j]= pgm_read_byte(&Font5x7[index]);//get the code 
				}
				display_buff[5] = 0x00;
			}
			currenr_seg_num = 0;
			i ++;
		}
		else
		{
			unsigned char temp;
			if(i < s.length())
			{
				unsigned int index = (s[i]-32)*5+currenr_seg_num;
				temp = pgm_read_byte(&Font5x7[index]);
			}
			else temp = 0x00;
			display_buff[0] = display_buff[1];
			display_buff[1] = display_buff[2];
			display_buff[2] = display_buff[3];
			display_buff[3] = display_buff[4];
			display_buff[4] = display_buff[5];
			display_buff[5] = temp;
			currenr_seg_num ++;
		}
		printWithTime(moving_time);//print with the array display_buff
	}
}
/*Function: Print something on the LED matrix with the global array display_buff      */
void LED5x7::print()
{ 
	for(uint8_t count = 0;count < 5;count ++)
	{
		unsigned char bit_select;
		if(disp_orientation == RIGHT_TO_LEFT)
		{
			bit_select = 4;
			edge_bit_selector = 0x01;//always select the LSB of the display control
									//byte that is read from the array Font5x7
		}
		else 
		{
			bit_select = 0;
			edge_bit_selector = 0x40;//0x40 = 0b0100 0000,select bit 6 of display control
									// byte that is read from the array Font5x7
			
		}
		for(unsigned char i=0;i<5;i++)// 5 bytes for each ASC Code;
		{
			unsigned int temp;// get the 1/5 code address for each asc;
			temp = display_buff[i];//get the code 
			turnOffLEDMatrix();//needed
			if(disp_orientation == RIGHT_TO_LEFT)
				digitalWrite(negative_pins[bit_select--],LOW);
			else digitalWrite(negative_pins[bit_select++],LOW);
			for(unsigned char j = 0;j < 7;j ++)
			{
				if(temp & edge_bit_selector) 
				{
					digitalWrite(positive_pins[j], HIGH);
					delayMicroseconds(5);
					digitalWrite(positive_pins[j], LOW);
				}
				else digitalWrite(positive_pins[j], LOW);
				if(disp_orientation == RIGHT_TO_LEFT)
					temp >>= 1;
				else temp <<= 1;
			}
		}
	}
}

void LED5x7::printWithTime(uint16_t display_time)
{
	interruptions = display_time / TIMER1_PERIOD;//the number of timer1 interruptions
	timer1_count = 0;
	flag_timeout = 0;
	Timer1.attachInterrupt( timerIsr );
	while(!flag_timeout)print();
	Timer1.stop();
}
/**********************************************************************/
/*Function: Set the display orientation for the 5x7 LED matrix and it */
/*		   takes effect the next time it print.						  */
/*Parameter:-uint8_t orientation,LEFT_TO_RIGHT or RIGHT_TO_LEFT;      */
/*Return:	void                      			                      */
void LED5x7::setOrientation(uint8_t orientation)
{
	disp_orientation = orientation;
}
/*Function: turn off all the LEDs and the negative pin of the LED is set HIGH */
/*			and the positive pin of the LED is set LOW*/
void LED5x7::turnOffLEDMatrix()
{
	for(unsigned char i = 0; i < 5;i ++)
	{
		digitalWrite(negative_pins[i],HIGH);
	}
	for(unsigned char i = 0; i < 7;i ++)
	{
		digitalWrite(positive_pins[i],LOW);
	}
}

void timerIsr()
{
	timer1_count ++;
	if(timer1_count == interruptions)flag_timeout = 1;
}
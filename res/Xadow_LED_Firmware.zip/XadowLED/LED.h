#ifndef __LED_H__
#define __LED_H__

#include "font.h"
#include <Arduino.h>

#define XADOW_LED_ADDR 0X04
/*Marco definitions for the pins of the Atmega168 which is connected with the*/
/* LED matrix.*/
//modified for the new version of LED Panel
/*
#define MATRIX_N0 4//PD4
#define MATRIX_N1 17//PC3
#define MATRIX_N2 16//PC2
#define MATRIX_N3 15//PC1
#define MATRIX_N4 14//PC0
*/
#define MATRIX_N0 14//PC0
#define MATRIX_N1 15//PC1
#define MATRIX_N2 16//PC2
#define MATRIX_N3 17//PC3
#define MATRIX_N4 4//PD4


#define MATRIX_P0 6//PD6
#define MATRIX_P1 5//PD5
#define MATRIX_P2 12//PB4
#define MATRIX_P3 11//PB3
#define MATRIX_P4 10//PB2
#define MATRIX_P5 9//PB1
#define MATRIX_P6 8//PB0

/*Marco definitions for the display orientation of the LED matrix*/
#define RIGHT_TO_LEFT 0
#define LEFT_TO_RIGHT 1
/*Macro definitions of the control commands from the xadow main board*/
#define DISP_CHAR_5X7	0x80
#define DISP_STRING		0x81
#define SET_DISP_ORIENTATION 0x82
#define POWER_DOWN		0x83

class LED5x7 {
public:
	//LED5x7(void);
	void init();
	void print(uint8_t ascii,uint16_t display_time);
	void printNumber(uint8_t number);
	void print(const String &,uint16_t moving_time);
	void setOrientation(uint8_t orientation);
private:
	void initDriveIOs();
	void print();
	void printWithTime(uint16_t display_time);
	void turnOffLEDMatrix();
	uint8_t disp_orientation;
	uint8_t edge_bit_selector;
};

#endif;
